package com.yash.tdddemo.testcase;
import static org.junit.Assert.*;
import org.junit.*;

import com.yash.tdddemo.*;
public class MyTestCase {

	@Test
	public void testFindMin() {
		System.out.println("Test find min is called");
		assertEquals(2,Algorithm.findMin(new int[] {12,2,3,45,6}));
		// it take two inputs first desired result, second input to that method 
		//test is fail as we suppose get 2 from the function but we get 0 
	}
	@Test
	public void testArea()
	{	
		System.out.println("Test area is called");
	  assertEquals(100,Algorithm.areaRect(10, 10));
	  assertEquals(10*10,Algorithm.areaRect(10, -10));
	}
	@Before
	public void m1CalledBeforeTestFun()
	{
		System.out.println("method m1 calledbefore any test is called");		
	}
	@After
	public void m2()
	{
		System.out.println("m2 is called after test end");
		
	}
	@BeforeClass
	public static void c1()
	{
		System.out.println("before test of class c1 is called");
	}
	@AfterClass
	public  static void c2()
	{
		System.out.println("after test of class c2 is called");
	}
	@Test
	public void testEqualString()
	{
		assertEquals("lina",Algorithm.reverseString("anil"));		
	}
}
