package com.yash.tdddemo;
import java.math.*;
public class Algorithm {
  
	public static int findMin(int a[])
	{
		 int min=a[0];
		 for(int i=1;i<a.length;i++)
			 if(a[i]<min)
				  min=a[i];		
		 return min;
	}
	public static int areaRect(int l,int w)
	{
		l=Math.abs(l);
		w=Math.abs(w);
		return (l*w);
	}
	public static String reverseString(String name)
	{
		String newname=new String();
		int i;
		char c;
		for(i=name.length()-1;i>=0;i--)
		{
			 c=name.charAt(i);
			 newname=newname+c;
		}
		return newname;
	}
}
